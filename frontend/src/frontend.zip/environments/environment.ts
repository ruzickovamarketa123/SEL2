export const environment = {
  production: false,
  backendUrl: 'http://localhost:8080',
  orsApiKey: 'eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6Ijg0ODE5ZTI1ZTFmMjA3OTIxMTYxZmYyYWM5MTllMTEwMzUzNzE4ODE4Zjk0MDFhNTFjZmJhYjE1IiwiaCI6Im11cm11cjY0In0='
};
